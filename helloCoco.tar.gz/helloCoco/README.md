# helloCoco

[![CI Status](https://img.shields.io/travis/AsafZalcman-jfrog/helloCoco.svg?style=flat)](https://travis-ci.org/AsafZalcman-jfrog/helloCoco)
[![Version](https://img.shields.io/cocoapods/v/helloCoco.svg?style=flat)](https://cocoapods.org/pods/helloCoco)
[![License](https://img.shields.io/cocoapods/l/helloCoco.svg?style=flat)](https://cocoapods.org/pods/helloCoco)
[![Platform](https://img.shields.io/cocoapods/p/helloCoco.svg?style=flat)](https://cocoapods.org/pods/helloCoco)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

helloCoco is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'helloCoco'
```

## Author

AsafZalcman-jfrog, asafz@jfrog.com

## License

helloCoco is available under the MIT license. See the LICENSE file for more info.
